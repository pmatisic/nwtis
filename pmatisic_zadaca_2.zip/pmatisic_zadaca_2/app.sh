#!/bin/sh

./scripts/baza.sh
cd pmatisic_zadaca_2_wa_1
./scripts/prva.sh
cd ..
./druga.sh
