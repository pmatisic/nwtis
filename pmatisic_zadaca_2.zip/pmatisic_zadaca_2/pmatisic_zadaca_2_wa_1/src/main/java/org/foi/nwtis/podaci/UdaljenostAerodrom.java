package org.foi.nwtis.podaci;

public record UdaljenostAerodrom(String icao, float km) {

}
