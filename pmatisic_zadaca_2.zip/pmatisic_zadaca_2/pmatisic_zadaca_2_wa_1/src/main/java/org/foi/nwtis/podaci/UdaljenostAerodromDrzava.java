package org.foi.nwtis.podaci;

public record UdaljenostAerodromDrzava(String icao, String drzava, float km) {

}
