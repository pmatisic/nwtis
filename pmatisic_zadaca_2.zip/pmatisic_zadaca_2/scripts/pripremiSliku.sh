#!/bin/bash

docker build -t nwtishsqldb_4:1.0.0 . &

wait
